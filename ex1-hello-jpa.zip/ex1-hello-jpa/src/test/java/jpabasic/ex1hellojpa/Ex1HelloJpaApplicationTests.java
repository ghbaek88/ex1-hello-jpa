package jpabasic.ex1hellojpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1HelloJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
